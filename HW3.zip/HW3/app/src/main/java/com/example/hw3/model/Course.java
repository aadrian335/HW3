package com.example.hw3.model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Course extends PersistentObject {

    protected String mCourseID;
    protected String mGrade;

    public Course(String mCourseID, String mGrade) {
        this.mCourseID = mCourseID;
        this.mGrade = mGrade;
    }

    public Course(){

    }

    public String getmCourseID() {
        return mCourseID;
    }

    public void setmCourseID(String mCourseID) {
        this.mCourseID = mCourseID;
    }

    public String getmGrade() {
        return mGrade;
    }

    public void setmGrade(String mGrade) {
        this.mGrade = mGrade;
    }

    @Override
    public void insert(SQLiteDatabase db) {
        ContentValues vals = new ContentValues();
        vals.put("Course ID", mCourseID);
        vals.put("Grade", mGrade);
        db.insert("Person", null, vals);
    }
    @Override
    public void createTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Vehicle (Make Text, Model Text, Vin Text, Owner INTEGER)");
    }

    @Override
    public void initFrom(SQLiteDatabase db, Cursor c) {
        mCourseID = c.getString(c.getColumnIndex("Course ID"));
        mGrade = c.getString(c.getColumnIndex("Grade"));
    }
}
