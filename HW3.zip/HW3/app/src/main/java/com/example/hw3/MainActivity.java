package com.example.hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    private Button addbtn;
    private EditText fn, ln, cwid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fn = (EditText)findViewById(R.id.editText1);
        ln = (EditText)findViewById(R.id.editText2);
        cwid = (EditText)findViewById(R.id.editText3);
        addbtn = (Button)findViewById(R.id.add_button);
        myDB = new DatabaseHelper(this);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String firstn = fn.getText().toString();
                String lastn = ln.getText().toString();
                int studentid = Integer.parseInt(cwid.getText().toString());

                addData(firstn, lastn, studentid);
                fn.setText("");
                ln.setText("");
                cwid.setText("");
            }
        });
    }

    public void addData(String fn, String ln, int cwid) {
        boolean insertData = myDB.addData(fn, ln, cwid);
    }
}
