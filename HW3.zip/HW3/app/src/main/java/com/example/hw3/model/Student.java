package com.example.hw3.model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class Student extends PersistentObject {
    protected String mFirstName;
    protected String mLastName;
    protected int mCwid;
    protected ArrayList<Course> mCourses;

    public Student() {

    }

    public Student(String mFirstName, String mLastName, int mCwid) {
        this.mFirstName = mFirstName;
        this.mLastName = mLastName;
        this.mCwid = mCwid;
    }

    public String getmFirstName() {
        return mFirstName;
    }

    public void setmFirstName(String mFirstName) {
        this.mFirstName = mFirstName;
    }

    public String getmLastName() {
        return mLastName;
    }

    public void setmLastName(String mLastName) {
        this.mLastName = mLastName;
    }

    public int getmCwid() {
        return mCwid;
    }

    public void setmCwid(int mCwid) {
        this.mCwid = mCwid;
    }

    public ArrayList<Course> getCourses() {
        return mCourses;
    }

    public void setmCourses(ArrayList<Course> courses) {
        mCourses = courses;
    }

    @Override
    public void insert(SQLiteDatabase db) {
        ContentValues vals = new ContentValues();
        vals.put("FirstName", mFirstName);
        vals.put("LastName", mLastName);
        vals.put("CWID", mCwid);
        db.insert("Person", null, vals);
        for (int i = 0; i < mCourses.size(); i++) {
            mCourses.get(i).insert(db);
        }
    }

    @Override
    public void initFrom(SQLiteDatabase db, Cursor c) {
        mFirstName = c.getString(c.getColumnIndex("FirstName"));
        mLastName = c.getString(c.getColumnIndex("LastName"));
        mCwid = c.getInt(c.getColumnIndex("CWID"));

        // construct the vehicle objects owned by the person
        mCourses = new ArrayList<Course>();
        Cursor cursor = db.query("Course", null, "Owner=?", new String[]{new Integer(mCwid).toString()}, null, null, null);
        if (cursor.getCount() >0) {
            while (cursor.moveToNext()) {
                Student vObj = new Student();
                vObj.initFrom(db, cursor);
            }
        }
    }

    @Override
    public void createTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Person (FirstName Text, LastName Text, CWID INTEGER)");
    }
}
