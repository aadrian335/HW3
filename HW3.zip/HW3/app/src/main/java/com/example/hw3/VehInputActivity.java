package com.example.hw3;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.hw3.model.StudentDB;

import java.util.ArrayList;

public class VehInputActivity extends AppCompatActivity {

    EditText fN;
    EditText lN;
    EditText cWid;
    Button bt;
    Button addCoursebt;
    ListView lv;
    ArrayList<String> arrayList;
    ArrayAdapter<String> adapter;
    protected int studentIndex;

    public ConstraintLayout mLayout;
    public LinearLayout lLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veh_input);

        //mLayout = (LinearLayout)findViewById(R.id.veh_input_layout_id);

        final int studentIndex = getIntent().getIntExtra("StudentIndex", 0);


        fN = (EditText) findViewById(R.id.editText); // First Name
        lN = (EditText) findViewById(R.id.editText2); // Last Name
        cWid = (EditText) findViewById(R.id.editText3); // CWID


        fN.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                StudentDB.getInstance().getmStudents().get(studentIndex).setmFirstName(fN.getText().toString());

            }
        });

        lN.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                StudentDB.getInstance().getmStudents().get(studentIndex).setmLastName(lN.getText().toString());


            }
        });

        cWid.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                StudentDB.getInstance().getmStudents().get(studentIndex).setmCwid(Integer.parseInt(cWid.getText().toString()));


            }
        });

        bt = (Button) findViewById(R.id.button);
        lv = (ListView) findViewById(R.id.lv_added);
        addCoursebt = (Button) findViewById(R.id.addCbutton);

        arrayList = new ArrayList<String>();

        adapter = new ArrayAdapter<>(VehInputActivity.this, android.R.layout.simple_list_item_1, arrayList);
        StudentDB.getInstance().getmStudents().get(studentIndex).setmFirstName(fN.getText().toString());


        lv.setAdapter(adapter);

        onBtnClick();

        onAddCBtnClick();
    }

    public void onBtnClick() {
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String firstName = fN.getText().toString();
                String lastName = lN.getText().toString();
                String text = cWid.getText().toString();
                int cwid = Integer.parseInt(text);

                StudentDB.setStudentObjects(firstName, lastName, cwid);

                //arrayList.add(firstName);
                adapter.notifyDataSetChanged();
                openSummActivity();
            }
        });
    }

    public void openSummActivity() {
        Intent intent = new Intent(this, SummaryLVActivity.class);
        startActivity(intent);
    }

    public void onAddCBtnClick() {
        addCoursebt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addET();
            }
        });
    }

    public void addET(){
        mLayout = findViewById(R.id.veh_input_layout_id);
        //View view = (View) findViewById(R.id.veh_input_layout_id);
        //Button button = (Button) view.findViewById(R.id.getStarted);

        //lLayout = mLayout.findViewById(R.id.linearlayout);
        EditText et1 = new EditText(this);
        EditText et2 = new EditText(this);
        et2.setPadding(0,150,0,0);
        et1.setText("Course Name");
        et2.setText("Grade");

        //lLayout.addView(et1);
        //lLayout.addView(et2);

        mLayout.addView(et1);
        mLayout.addView(et2);
    }
}
