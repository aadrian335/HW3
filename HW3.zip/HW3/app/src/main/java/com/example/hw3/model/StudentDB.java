package com.example.hw3.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.util.ArrayList;

public class StudentDB {
    private static final StudentDB ourInstance = new StudentDB();

    static public ArrayList<Student> mStudents; //changed from protected

    static public StudentDB getInstance() { return ourInstance; }

    SQLiteDatabase mSQLiteDatabase;

    public StudentDB(Context context) {

        File dbFile = context.getDatabasePath("student.db");
        mSQLiteDatabase = SQLiteDatabase.openOrCreateDatabase(dbFile, null);

        new Student().createTable(mSQLiteDatabase);
        new Course().createTable(mSQLiteDatabase);

        // createPersonObjects();
    }

    private StudentDB() { createStudentObjects(); }

    public ArrayList<Student> getmStudents() { return mStudents; }

    public void setmStudents(ArrayList<Student> students) { mStudents = students; }

    static public void setStudentObjects(String fn, String ln, int cwid) {
        Student p = new Student(fn, ln, cwid);
        ArrayList<Course> courses = new ArrayList<Course>();
        courses.add(new Course("CPSC411", "A"));
        p.setmCourses(courses);
        //mStudents = new ArrayList<Student>();
        mStudents.add(p);
    }

    public ArrayList<Student> retrievePersonObjects() {
        mStudents = new ArrayList<Student>();
        Cursor cursor = mSQLiteDatabase.query("Person", null, null, null, null, null, null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                Student pObj = new Student();
                pObj.initFrom(mSQLiteDatabase, cursor);
                mStudents.add(pObj);
            }
        }
        return mStudents;
    }

    protected void createStudentObjects() {
        // Create Student object



        Student p = new Student("First Name:   ", "   Last Name:   ", 0);
        ArrayList<Course> courses = new ArrayList<Course>();
        courses.add(new Course("CPSC411", "A"));
        p.setmCourses(courses);
        mStudents = new ArrayList<Student>();
        mStudents.add(p);
        //ArrayList<Student> personList = new ArrayList<Student>();
        //personList.add(p);
        // Create another Student object
        /*
        p = new Student("", "", 0);
        courses = new ArrayList<Course>();
        courses.add(new Course("CPSC359", "B+"));
        p.setmCourses(courses);
        mStudents.add(p);
        */


        //personList.add(p);
        //
        //StudentDB.getInstance().setmStudents(personList);
    }
}
